def main():
    words = fetch_words()
    print_words(words)


if __name__ == '__main__':
    main()
